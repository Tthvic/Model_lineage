import torch

def get_parent_child_subset(data: torch.Tensor, threshold: float):

    metric = torch.norm(data,p=2, dim = -1)
    parent_subset = torch.where(metric <= threshold)[0]
    child_subset = torch.where(metric > threshold)[0]
    return parent_subset, child_subset
